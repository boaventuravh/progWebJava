package exemplo.seguranca.dtos;

public record DadosAutenticacao(String login, String senha) {

}
