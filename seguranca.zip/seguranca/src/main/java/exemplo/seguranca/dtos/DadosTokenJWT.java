package exemplo.seguranca.dtos;

public record DadosTokenJWT (String token) {

}
